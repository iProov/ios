#import "GPUImageTwoInputFilter.h"

@interface GPUImageDivideBlendFilter : GPUImageTwoInputFilter

@end
