Loco ios export: iOS Localizable.strings
Project: iProov
Release: Working copy
Exported at: Fri, 12 Jul 2019 11:53:05 +0100
Exported by: Jonathan Ellis