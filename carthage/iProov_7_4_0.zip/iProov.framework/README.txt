Loco ios export: iOS Localizable.strings
Project: iProov
Release: Working copy
Exported at: Mon, 16 Sep 2019 12:31:02 +0100
Exported by: Jonathan Ellis